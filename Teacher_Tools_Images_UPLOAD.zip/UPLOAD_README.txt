Examine the Past — Teacher Tools Homepage Card Images
8 optimized WebP images, darkened 25% for overlay text.
Original screenshot content and aspect ratios preserved.
Upload the eight .webp files to the website image/assets directory.
Place each as a background in its matching homepage card, using background-size: cover and a further CSS gradient if needed for readable foreground labels.
Keep card sizes unchanged.
