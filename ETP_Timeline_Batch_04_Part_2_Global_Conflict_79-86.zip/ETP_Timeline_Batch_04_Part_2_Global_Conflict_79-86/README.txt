EXAMINE THE PAST — GLOBAL CONFLICT — BATCH 04

Use Website_WebP for the timeline: 1800 x 600 pixels, full-bleed 3:1 banners.
Full_Resolution_JPEG contains larger 2172 x 724 copies for archival use.
Filenames carry the timeline card position and exact title. placement.csv and placement.json provide the title-to-file mapping.
Upload extracted WebP files to the GitHub assets folder; retain the filenames. Do not serve the ZIP or the archival JPEGs on the timeline.

These are AI-created interpretive illustrations, not historical photographs or primary-source evidence.
The Holocaust image uses a memorial still life. The Mahatma Gandhi image represents the Salt March through anonymous marchers and salt, rather than a Gandhi portrait. The Cold War image is a composite of divided Berlin during the Cold War, not a reconstruction of a single dated event.

79. Year of Africa
80. March on Washington
81. Soweto Uprising
82. Fall of the Berlin Wall
83. Mahatma Gandhi
84. Martin Luther King Jr.
85. Harlem Renaissance
86. Apollo 11 Moon Landing
