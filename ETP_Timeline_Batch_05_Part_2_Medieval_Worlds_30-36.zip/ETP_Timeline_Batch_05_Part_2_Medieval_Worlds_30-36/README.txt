EXAMINE THE PAST — BATCH 05

Use Website_WebP for the timeline: 1800 x 600 pixels, full-bleed 3:1 banners, quality-optimized.
Full_Resolution_JPEG contains larger 2172 x 724 copies for archival use.
Filenames carry the timeline card position and exact title in a filesystem-safe form. placement.csv and placement.json preserve exact Unicode titles and descriptions.
Upload extracted WebP files to the GitHub assets folder; retain the filenames. Do not serve the ZIP or archival JPEGs on the timeline. Lazy loading is recommended during installation.
These are AI-created interpretive historical illustrations, not historical photographs, primary-source evidence, or authenticated portraits. Architecture and scenes are artistic reconstructions.
This batch is prepared for upload; it has not yet been installed on the live timeline.

30. Kingdoms & Courts
31. Centers of Learning Flourish
32. Crusading Movements
33. The Black Death
34. Ghana Empire and Trans-Saharan Trade
35. Swahili Coast City-States
36. Great Zimbabwe
