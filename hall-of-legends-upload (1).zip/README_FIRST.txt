HALL OF LEGENDS — PRODUCT-MATCHED PORTRAIT REPLACEMENT PACK
This package contains exactly 141 WebP portraits and a checksum manifest.
32 portraits were replaced using the user's newly uploaded original product illustrations:
- 21 additional African figures (121-141), replacing severely overcropped face-only images.
- 11 matching illustrations in the original 120, replacing crops where the clean version provides more room around headwear.
The remaining 109 are byte-for-byte unchanged from the original installed pack.
ALL 32 replacements use the full 1200x1200 image, resized to 512x512 without crop or distortion.
No new faces were generated, no transparency was added, no AI inpainting was used.

UPLOAD:
Rename this ZIP to hall-of-legends-upload.zip before uploading it to the ROOT of the
wdwedu/examine-the-past-home repository. The existing GitHub workflow only accepts
that exact filename and replaces the current 141 portraits. The workflow removes
the uploaded ZIP after installation, so no duplicate portrait directory is created.

Remaining QA: see top_edge_review.csv. These have full faces but some headwear/hair
may be cropped at the upper edge of their current artwork.
