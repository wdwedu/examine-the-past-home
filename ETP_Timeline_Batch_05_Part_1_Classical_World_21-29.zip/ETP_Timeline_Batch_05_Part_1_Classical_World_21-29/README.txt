EXAMINE THE PAST — BATCH 05

Use Website_WebP for the timeline: 1800 x 600 pixels, full-bleed 3:1 banners, quality-optimized.
Full_Resolution_JPEG contains larger 2172 x 724 copies for archival use.
Filenames carry the timeline card position and exact title in a filesystem-safe form. placement.csv and placement.json preserve exact Unicode titles and descriptions.
Upload extracted WebP files to the GitHub assets folder; retain the filenames. Do not serve the ZIP or archival JPEGs on the timeline. Lazy loading is recommended during installation.
These are AI-created interpretive historical illustrations, not historical photographs, primary-source evidence, or authenticated portraits. Architecture and scenes are artistic reconstructions.
This batch is prepared for upload; it has not yet been installed on the live timeline.

21. Silk Roads Networks
22. Kingdom of Kush at Meroë
23. Mauryan Empire and Ashoka
24. Imperial China Unifies
25. Kingdom of Aksum
26. Classic Maya Cities
27. Confucius
28. Ashoka
29. Hypatia of Alexandria
